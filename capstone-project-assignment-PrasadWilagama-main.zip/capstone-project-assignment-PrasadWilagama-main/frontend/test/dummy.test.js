fixture`Dummy Test`
    .page`https://devexpress.github.io/testcafe/example`;

test('Dummy Test', async t => {
});
