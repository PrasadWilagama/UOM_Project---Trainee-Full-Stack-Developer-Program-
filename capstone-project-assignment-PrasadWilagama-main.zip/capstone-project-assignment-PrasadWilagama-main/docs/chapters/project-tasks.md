## 4. Project tasks

The following tasks will help you to implement the `student` related functionalities of the `capstone project`. Complete them in the given order.

1. [Backend Tasks](/docs/tasks/backend-tasks.md)
2. [Frontend Tasks](/docs/tasks/frontend-tasks.md)
